# Input.in can be used to perfrom the PSI4 optimization with python interface
# We can also calculate total time taken to complete the jobs as well as memory
 
